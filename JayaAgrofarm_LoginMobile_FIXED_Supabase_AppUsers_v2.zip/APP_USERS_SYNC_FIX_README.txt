

==============================
PERBAIKAN APP_USERS SYNC — 2026-10-05
==============================

Perubahan pada js/auth.js:
- Nama pengguna tidak lagi dibaca dari localStorage.
- Nama farm tidak lagi dibaca dari localStorage.
- Nama pengguna/nama farm persisten menggunakan public.app_users.
- Setelah login dan saat sesi Supabase dipulihkan, profil Auth otomatis disinkronkan ke app_users.
- Update profil sekarang memeriksa error Supabase secara eksplisit; UI tidak lagi menganggap update berhasil jika database menolak.
- Tidak ada localStorage.getItem/setItem untuk identitas akun (name/farm_name).

Catatan:
- localStorage yang tersisa di aplikasi hanya untuk preferensi/UI seperti lokasi manual dan status instalasi PWA, bukan data bisnis atau identitas akun.
- Pastikan SUPABASE_ISOLASI_AKUN.sql sudah dijalankan di project Supabase sebelum deploy.
- Setelah deploy Netlify, logout lalu login kembali pada browser yang digunakan untuk pengujian.
