/**
 * Sistem Autentikasi Supabase Auth & RBAC Multi-Tenant
 * Jaya Agrofarm Nusantara
 * Menggunakan Supabase Auth (signInWithPassword, signOut, getSession)
 * dan verifikasi tabel: app_users, tenant_users, whitelist.
 */

// Super Administrator: dua akun dengan hak akses penuh
const MASTER_ADMIN = {
    id: 'admin-master',
    email: 'pratamajayapreneur@gmail.com',
    name: 'Jaya Agrofarm Administrator',
    role: 'OWNER_ADMIN',
    status: 'active'
};
const SUPER_ADMIN_EMAILS = [
    'pratamajayapreneur@gmail.com',
    'kandiapj23@gmail.com'
];
const SUPER_ADMIN_PROFILES = {
    'pratamajayapreneur@gmail.com': { name: 'Jaya Agrofarm Administrator' },
    'kandiapj23@gmail.com': { name: 'Kandi Andika Pratama Jaya' }
};
const isSuperAdminEmail = (email) => SUPER_ADMIN_EMAILS.includes(String(email || '').trim().toLowerCase());
window.MASTER_ADMIN = MASTER_ADMIN;
window.SUPER_ADMIN_EMAILS = SUPER_ADMIN_EMAILS;
window.isSuperAdminEmail = isSuperAdminEmail;

// Daftar Organisasi / Tenant Bawaan
const TENANTS = {
    'tenant-nusantara': {
        id: 'tenant-nusantara',
        slug: 'agro-nusantara',
        code: 'AGRO-01',
        name: 'Jaya Agrofarm Nusantara',
        sector: 'Tanaman Pangan & Hortikultura',
        plan: 'Premium Member'
    },
    'tenant-user-pratamajayapreneur-gmail-com': {
        id: 'tenant-user-pratamajayapreneur-gmail-com',
        slug: 'agro-nusantara',
        code: 'AGRO-01',
        name: 'Jaya Agrofarm Nusantara',
        sector: 'Tanaman Pangan & Hortikultura',
        plan: 'Premium Member'
    },
    'tenant-lembang': {
        id: 'tenant-lembang',
        slug: 'agro-lembang',
        code: 'AGRO-02',
        name: 'Kebun Dataran Tinggi Lestari Lembang',
        sector: 'Hortikultura Sayur & Buah',
        plan: 'Premium Member'
    },
    'tenant-user-petani-sukses-gmail-com': {
        id: 'tenant-user-petani-sukses-gmail-com',
        slug: 'agro-lembang',
        code: 'AGRO-02',
        name: 'Kebun Dataran Tinggi Lestari Lembang (Hendra)',
        sector: 'Hortikultura Sayur & Buah',
        plan: 'Premium Member'
    },
    'tenant-makmur': {
        id: 'tenant-makmur',
        slug: 'tani-makmur',
        code: 'AGRO-03',
        name: 'Koperasi Tani Makmur Subang',
        sector: 'Sentra Padi & Jagung',
        plan: 'Premium Member'
    },
    'tenant-user-agrobisnis-subang-gmail-com': {
        id: 'tenant-user-agrobisnis-subang-gmail-com',
        slug: 'tani-makmur',
        code: 'AGRO-03',
        name: 'Koperasi Tani Makmur Subang',
        sector: 'Sentra Padi & Jagung',
        plan: 'Premium Member'
    },
    'tenant-user-kandiapj23-gmail-com': {
        id: 'tenant-user-kandiapj23-gmail-com',
        slug: 'agro-nusantara',
        code: 'AGRO-01',
        name: 'Jaya Agrofarm Nusantara',
        sector: 'Tanaman Pangan & Hortikultura',
        plan: 'Premium Member'
    },
    'tenant-user-kandiandika23-gmail-com': {
        id: 'tenant-user-kandiandika23-gmail-com',
        slug: 'agro-nusantara',
        code: 'AGRO-01',
        name: 'Jaya Agrofarm Nusantara',
        sector: 'Tanaman Pangan & Hortikultura',
        plan: 'Premium Member'
    }
};
window.TENANTS = TENANTS;

// Setiap akun pembeli mendapatkan workspace/tenant unik.
// Dua email berbeda tidak pernah berbagi tenant_id.
function tenantIdForEmail(email) {
    const clean = String(email || '').trim().toLowerCase();
    const slug = clean
        .replace(/@/g, '-')
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/^-+|-+$/g, '')
        .slice(0, 80);
    return `tenant-user-${slug || 'unknown'}`;
}
window.tenantIdForEmail = tenantIdForEmail;

class WhitelistAuthService {
    constructor() {
        this.currentUser = null;
        this.currentSession = null;
        this.whitelistCache = [];
    }

    getService() {
        return window.databaseService || null;
    }

    getSupabase() {
        return (window.databaseService && window.databaseService.supabase) || window.supabaseClient || null;
    }

    // ----------------------------------------------------
    // PEMERIKSAAN SESI SAAT APLIKASI DIBUKA (getSession)
    // ----------------------------------------------------
    async checkSession() {
        const s = this.getService();
        if (!s) return null;

        try {
            const session = await s.authGetSession();
            if (session && session.user) {
                this.currentSession = session;
                const email = session.user.email.toLowerCase();
                const appUser = await this.verifyUserWithDatabase(email, session.user.id);
                this.currentUser = appUser;
                const profileSync = await this.syncAppUserRecord();
                if (!profileSync.success) {
                    console.warn('[Supabase Auth] Profil app_users belum tersinkron:', profileSync.message);
                }
                if (window.db) {
                    window.db.setTenant(appUser.tenantId);
                }
                return appUser;
            }
        } catch (err) {
            console.error('[Supabase Auth] Gagal memuat sesi aktif:', err);
        }

        return null;
    }

    // Verifikasi user terhadap tabel app_users, tenant_users, & whitelist di Supabase
    async verifyUserWithDatabase(email, authUserId = null) {
        const s = this.getService();
        const supabase = this.getSupabase();
        const cleanEmail = email.trim().toLowerCase();
        const isMaster = isSuperAdminEmail(cleanEmail);

        let tenantId = null;
        let role = isMaster ? 'OWNER_ADMIN' : 'BUYER';
        let userName = cleanEmail.split('@')[0];

        // 1. Cek dari service getWhitelist (mendukung Supabase dan offline fallback)
        let wlList = [];
        try {
            if (s && s.getWhitelist) {
                wlList = await s.getWhitelist(null);
            }
        } catch (e) {
            console.warn('[verifyUserWithDatabase getWhitelist]', e);
        }

        const matched = wlList.find(w => w.email.toLowerCase() === cleanEmail && w.status !== 'inactive');
        if (matched) {
            if (matched.tenant_id) tenantId = matched.tenant_id;
            if (matched.name) userName = matched.name;
        } else if (!isMaster) {
            const isSeed = ['petani.sukses@gmail.com', 'bambang@agrofarm.id', 'agrobisnis.subang@gmail.com', 'kandiandika23@gmail.com', 'kandiapj23@gmail.com'].includes(cleanEmail);
            if (!isSeed) {
                const allowed = s && s.authCheckAccess ? await s.authCheckAccess(cleanEmail) : false;
                if (!allowed) {
                    throw new Error('Email Anda belum terdaftar dalam Whitelist atau aksesnya tidak aktif.');
                }
            }
        }

        let userRow = null;
        if (supabase && !s?.isDummyKey) {
            try {
                const { data: row } = await supabase
                    .from('app_users')
                    .select('*')
                    .eq('email', cleanEmail)
                    .maybeSingle();
                if (row) {
                    userRow = row;
                    if (row.tenant_id) tenantId = row.tenant_id;
                    if (row.role) role = row.role;
                    if (row.name) userName = row.name;
                }
            } catch (userErr) {
                console.warn('[verifyUserWithDatabase app_users]', userErr?.message || userErr);
            }

            try {
                const { data: tu } = await supabase
                    .from('tenant_users')
                    .select('*')
                    .eq('email', cleanEmail)
                    .maybeSingle();
                if (tu?.tenant_id) tenantId = tu.tenant_id;
            } catch (tenantErr) {
                console.warn('[verifyUserWithDatabase tenant_users]', tenantErr?.message || tenantErr);
            }
        }

        // Resolusi Nama Akun Spesifik
        if (SUPER_ADMIN_PROFILES[cleanEmail]) {
            userName = SUPER_ADMIN_PROFILES[cleanEmail].name;
        } else if (!userName || userName.includes('@')) {
            userName = cleanEmail.split('@')[0];
        }

        // Nama profil utama SELALU berasal dari Supabase (app_users/whitelist).
        // Jangan membaca localStorage untuk identitas akun agar nama akun tidak
        // tercampur ketika perangkat/browser dipakai oleh beberapa akun.

        // Fallback terakhir tetap unik per email; tidak pernah kembali ke
        // tenant-nusantara bersama milik akun lain.
        if (!tenantId) {
            tenantId = tenantIdForEmail(cleanEmail);
        }

        // Resolusi Nama Farm / Kebun Per User / Tenant.
        // Sumber persisten hanya app_users.farm_name, bukan localStorage.
        let farmName = '';
        if (userRow && userRow.farm_name) {
            farmName = userRow.farm_name;
        }

        if (!farmName) {
            if (isSuperAdminEmail(cleanEmail)) {
                farmName = 'Jaya Agrofarm Nusantara';
            } else if (cleanEmail.includes('lembang') || cleanEmail.includes('petani.sukses')) {
                farmName = 'Kebun Dataran Tinggi Lembang';
            } else if (cleanEmail.includes('subang') || cleanEmail.includes('agrobisnis')) {
                farmName = 'Sentra Tani Makmur Subang';
            } else if (cleanEmail.includes('bambang')) {
                farmName = 'Agro Nusantara Sentra';
            } else {
                farmName = `Kebun ${userName || 'Jaya Agrofarm'}`;
            }
        }

        const userObj = {
            id: authUserId || 'usr-' + Date.now(),
            email: cleanEmail,
            name: userName,
            farm_name: farmName,
            role: isMaster ? 'OWNER_ADMIN' : role,
            tenantId: tenantId,
            loginAt: new Date().toISOString()
        };

        return userObj;
    }

    // ----------------------------------------------------
    // SINKRONISASI PROFIL AUTH -> public.app_users
    // ----------------------------------------------------
    // app_users menjadi sumber data profil yang persisten.
    // localStorage TIDAK dipakai untuk nama pengguna/nama farm.
    async syncAppUserRecord() {
        if (!this.currentUser || !this.currentSession?.user) {
            return { success: false, message: 'Sesi pengguna belum tersedia.' };
        }

        const supabase = this.getSupabase();
        if (!supabase) {
            return { success: false, message: 'Koneksi Supabase belum tersedia.' };
        }

        const authUser = this.currentSession.user;
        const email = String(this.currentUser.email || authUser.email || '').trim().toLowerCase();
        const tenantId = this.currentUser.tenantId;

        if (!email || !tenantId) {
            return { success: false, message: 'Identitas akun atau tenant belum lengkap.' };
        }

        const payload = {
            id: authUser.id,
            email,
            name: String(this.currentUser.name || email.split('@')[0]).trim(),
            role: this.currentUser.role === 'OWNER_ADMIN' ? 'OWNER_ADMIN' : 'farmer',
            tenant_id: tenantId,
            farm_name: String(this.currentUser.farm_name || '').trim() || null,
            updated_at: new Date().toISOString()
        };

        try {
            const { data: existing, error: selectError } = await supabase
                .from('app_users')
                .select('id,email')
                .eq('email', email)
                .maybeSingle();

            if (selectError) throw selectError;

            if (existing) {
                // PENTING: app_users adalah sumber kebenaran profil.
                // Saat login/checkSession, JANGAN menulis name/farm_name dari
                // currentUser (yang bisa berasal dari fallback/whitelist/device)
                // kembali ke database. Jika dilakukan, device B dapat menimpa
                // nama yang baru disimpan dari device A.
                // Profil existing hanya dibaca di tahap ini. Perubahan profil
                // harus melalui updateUserName()/updateFarmName() secara eksplisit.
                return { success: true, existing: true, message: 'Profil app_users existing dipertahankan.' };
            } else {
                const { error: insertError } = await supabase
                    .from('app_users')
                    .insert(payload);

                if (insertError) throw insertError;
            }

            return { success: true };
        } catch (err) {
            console.error('[syncAppUserRecord]', err);
            return {
                success: false,
                message: err?.message || 'Gagal menyinkronkan profil akun ke Supabase.'
            };
        }
    }

    // ----------------------------------------------------
    // LOGIN PENGGUNA (SUPABASE AUTH signInWithPassword)
    // ----------------------------------------------------
    async registerApprovedUser(email, password, name = '') {
        if (!email || !password) {
            return { success: false, message: 'Email dan password wajib diisi.' };
        }
        if (password.length < 8) {
            return { success: false, message: 'Password minimal 8 karakter.' };
        }
        const cleanEmail = email.trim().toLowerCase();
        const s = this.getService();
        if (!s || !s.authSignUp) {
            return { success: false, message: 'Layanan autentikasi belum siap.' };
        }
        try {
            const allowed = await s.authCheckAccess(cleanEmail);
            if (!allowed) {
                return { success: false, message: 'Email belum disetujui admin atau pembayaran belum aktif. Hubungi administrator.' };
            }
            const data = await s.authSignUp(cleanEmail, password, { full_name: name || cleanEmail.split('@')[0] });
            if (data?.session && data?.user) {
                this.currentSession = data.session;
                this.currentUser = await this.verifyUserWithDatabase(cleanEmail, data.user.id);

                // Pastikan identitas Auth tersimpan di public.app_users.
                const profileSync = await this.syncAppUserRecord();
                if (!profileSync.success) {
                    console.warn('[Sync user tables notice]:', profileSync.message);
                }

                if (window.db) {
                    window.db.setTenant(this.currentUser.tenantId);
                    await window.db.loadAllData(this.currentUser.tenantId);
                }
                return { success: true, user: this.currentUser, confirmed: true };
            }
            return { success: true, confirmed: false, message: 'Akun berhasil dibuat. Jika konfirmasi email aktif di Supabase, silakan konfirmasi email lalu login.' };
        } catch (err) {
            console.error('[Supabase Register Error]:', err);
            return { success: false, message: err?.message || 'Gagal membuat akun.' };
        }
    }

    async login(email, password) {
        if (!email || !password) {
            return { success: false, message: 'Alamat email dan kata sandi wajib diisi.' };
        }

        const cleanEmail = email.trim().toLowerCase();
        const s = this.getService();
        if (!s) {
            return { success: false, message: 'Layanan autentikasi belum siap.' };
        }

        try {
            const allowed = s.authCheckAccess ? await s.authCheckAccess(cleanEmail) : false;
            if (!allowed && !isSuperAdminEmail(cleanEmail)) {
                return { success: false, message: 'Akses ditolak. Email Anda belum disetujui admin atau pembayaran belum aktif.' };
            }

            const authData = await s.authSignIn(cleanEmail, password);
            this.currentSession = authData.session;
            const appUser = await this.verifyUserWithDatabase(cleanEmail, authData.user.id);
            this.currentUser = appUser;

            const profileSync = await this.syncAppUserRecord();
            if (!profileSync.success) {
                console.warn('[Supabase Auth] Profil app_users belum tersinkron:', profileSync.message);
            }

            if (window.db) {
                window.db.setTenant(appUser.tenantId);
                await window.db.loadAllData(appUser.tenantId);
            }

            return { success: true, user: appUser };
        } catch (err) {
            console.error('[Supabase Login Error]:', err);
            return {
                success: false,
                message: err?.message || 'Gagal masuk. Periksa email, password, dan akun Supabase Auth Anda.'
            };
        }
    }

    // Login khusus Administrator
    async loginAdmin(email, password) {
        if (!email || !password) {
            return { success: false, message: 'Masukkan email dan password Administrator.' };
        }

        const cleanEmail = email.trim().toLowerCase();
        if (!isSuperAdminEmail(cleanEmail)) {
            return { success: false, message: 'Akun administrator tidak dikenali. Gunakan salah satu akun Super Admin yang terdaftar.' };
        }

        const result = await this.login(cleanEmail, password);
        if (!result.success) return result;
        if (!this.isAdmin()) {
            await this.logout();
            return { success: false, message: 'Akun Supabase ini tidak memiliki role administrator.' };
        }
        return result;
    }

    // ----------------------------------------------------
    // LOGOUT (SUPABASE AUTH signOut)
    // ----------------------------------------------------
    async logout() {
        const s = this.getService();
        if (s && s.authSignOut) {
            try {
                await s.authSignOut();
            } catch (err) {
                console.error('[Supabase Auth SignOut Error]:', err);
            }
        }
        this.currentUser = null;
        this.currentSession = null;
    }

    getCurrentUser() {
        return this.currentUser;
    }

    isAuthenticated() {
        return !!this.currentUser;
    }

    isAdmin() {
        if (!this.currentUser) return false;
        return this.currentUser.role === 'OWNER_ADMIN' || isSuperAdminEmail(this.currentUser.email);
    }

    getCurrentTenantId() {
        return (this.currentUser && this.currentUser.tenantId) || null;
    }

    getCurrentTenant() {
        const tenantId = this.getCurrentTenantId();
        if (TENANTS[tenantId]) return TENANTS[tenantId];

        const user = this.currentUser || {};
        return {
            id: tenantId,
            slug: tenantId,
            code: 'USER-WORKSPACE',
            name: user.farm_name || (user.name ? `Workspace ${user.name}` : 'Workspace Pribadi'),
            sector: 'Manajemen Pertanian',
            plan: 'Premium Member'
        };
    }

    async updateUserName(newUserName) {
        if (!this.currentUser) return { success: false, message: 'User belum login' };
        const cleanName = String(newUserName || '').trim().replace(/\s+/g, ' ');
        if (!cleanName) return { success: false, message: 'Nama pengguna tidak boleh kosong' };
        if (cleanName.length < 2) return { success: false, message: 'Nama pengguna minimal 2 karakter' };
        if (cleanName.length > 80) return { success: false, message: 'Nama pengguna maksimal 80 karakter' };

        const email = String(this.currentUser.email || '').trim().toLowerCase();
        const supabase = this.getSupabase();

        if (!supabase || !email) {
            return { success: false, message: 'Koneksi Supabase belum tersedia.' };
        }

        // Supabase adalah sumber data persisten. Jangan menulis profil ke localStorage.
        try {
            const { data: existing, error: selectError } = await supabase
                .from('app_users')
                .select('id')
                .eq('email', email)
                .maybeSingle();

            if (selectError) throw selectError;

            const profilePayload = {
                name: cleanName,
                updated_at: new Date().toISOString()
            };

            let dbError = null;
            if (existing) {
                const result = await supabase
                    .from('app_users')
                    .update(profilePayload)
                    .eq('email', email);
                dbError = result.error;
            } else {
                const result = await supabase
                    .from('app_users')
                    .insert({
                        id: this.currentSession?.user?.id,
                        email,
                        name: cleanName,
                        role: this.currentUser.role === 'OWNER_ADMIN' ? 'OWNER_ADMIN' : 'farmer',
                        tenant_id: this.currentUser.tenantId,
                        farm_name: this.currentUser.farm_name || null,
                        updated_at: new Date().toISOString()
                    });
                dbError = result.error;
            }

            if (dbError) throw dbError;
        } catch (err) {
            console.error('[updateUserName Supabase app_users]', err);
            return { success: false, message: err?.message || 'Nama gagal disimpan ke Supabase.' };
        }

        this.currentUser.name = cleanName;

        // Sinkronkan juga metadata Auth jika tersedia.
        try {
            if (this.currentSession?.user && supabase?.auth?.updateUser) {
                await supabase.auth.updateUser({ data: { full_name: cleanName, name: cleanName } });
            }
        } catch (err) {
            console.warn('[updateUserName Supabase Auth metadata]', err);
        }

        return { success: true, name: cleanName };
    }

    async updateFarmName(newFarmName) {
        if (!this.currentUser) return { success: false, message: 'User belum login' };
        const cleanName = String(newFarmName || '').trim();
        if (!cleanName) return { success: false, message: 'Nama farm tidak boleh kosong' };

        const tenantId = this.currentUser.tenantId;
        const email = String(this.currentUser.email || '').trim().toLowerCase();
        const supabase = this.getSupabase();

        if (!supabase || !email || !tenantId) {
            return { success: false, message: 'Koneksi Supabase atau identitas akun belum tersedia.' };
        }

        try {
            const { data: existing, error: selectError } = await supabase
                .from('app_users')
                .select('id')
                .eq('email', email)
                .maybeSingle();

            if (selectError) throw selectError;

            let dbError = null;
            if (existing) {
                const result = await supabase
                    .from('app_users')
                    .update({ farm_name: cleanName, updated_at: new Date().toISOString() })
                    .eq('email', email);
                dbError = result.error;
            } else {
                const result = await supabase
                    .from('app_users')
                    .insert({
                        id: this.currentSession?.user?.id,
                        email,
                        name: this.currentUser.name || email.split('@')[0],
                        role: this.currentUser.role === 'OWNER_ADMIN' ? 'OWNER_ADMIN' : 'farmer',
                        tenant_id: tenantId,
                        farm_name: cleanName,
                        updated_at: new Date().toISOString()
                    });
                dbError = result.error;
            }

            if (dbError) throw dbError;
        } catch (err) {
            console.error('[updateFarmName Supabase app_users]', err);
            return { success: false, message: err?.message || 'Nama farm gagal disimpan ke Supabase.' };
        }

        this.currentUser.farm_name = cleanName;
        return { success: true, farm_name: cleanName };
    }

    getAuthToken() {
        if (this.currentSession?.access_token) return this.currentSession.access_token;
        if (this.currentUser?.token) return this.currentUser.token;
        return this.currentUser ? `sb-token-${this.currentUser.id}` : '';
    }

    resolveTenantIdForEmail(email) {
        return tenantIdForEmail(email);
    }

   // ----------------------------------------------------
    // WHITELIST MANAGEMENT (SUPABASE POSTGRESQL)
    // ----------------------------------------------------
    async loadWhitelist() {
        const s = this.getService();
        if (!s) return [];
        try {
            const list = await s.getWhitelist(null);
            this.whitelistCache = list || [];
        } catch (e) {
            console.warn('[loadWhitelist notice]', e);
        }
        return this.whitelistCache || [];
    }

    getWhitelist() {
        return this.whitelistCache || [];
    }

    async addToWhitelist(email, name, notes, tenantId = null) {
        const s = this.getService();
        if (!s) {
            return { success: false, message: 'Layanan database belum siap.' };
        }

        const cleanEmail = email.trim().toLowerCase();
        const payload = {
            tenant_id: tenantId || tenantIdForEmail(cleanEmail),
            email: cleanEmail,
            name: name || cleanEmail.split('@')[0],
            notes: notes || 'Premium Member',
            status: 'active'
        };

        try {
            const result = await s.addToWhitelist(payload);
            await this.loadWhitelist();
            return {
                success: true,
                item: result,
                message: `Email ${cleanEmail} berhasil disetujui & ditambahkan ke Whitelist!`
            };
        } catch (err) {
            return {
                success: false,
                message: err.message || 'Gagal menambahkan ke whitelist.'
            };
        }
    }

    async removeFromWhitelist(idOrEmail) {
        const s = this.getService();
        if (!s) {
            return { success: false, message: 'Layanan database belum siap.' };
        }

        try {
            await s.removeFromWhitelist(idOrEmail);
            await this.loadWhitelist();
            return {
                success: true,
                message: 'Izin akses berhasil dicabut.'
            };
        } catch (err) {
            return {
                success: false,
                message: err.message || 'Gagal mencabut akses.'
            };
        }
    }
}

// Inisialisasi Singleton Auth Service
window.auth = new WhitelistAuthService();
